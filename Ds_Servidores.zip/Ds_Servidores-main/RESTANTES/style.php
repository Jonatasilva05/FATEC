<style type="text/css">
    
    .modulo {
        margin: 0 auto;
        width: 900px;
    }

    .card1,
    .card2,
    .card3,
    .card4,
    .card5,
    .card6,
    .card7,
    .card8,
    .card9,
    .card10,
    .card11,
    .card12,
    .card13,
    .card14,
    .card15,
    .card16,
    .card17,
    .card18,
    .card19 {
        border: none;
        border: 2px solid;
        border-radius: 25px;
        padding: 10px;
    }

    .phpDiv {
        background: #000;
        color: #fff;
        height: 100px;
        display: flex;
        justify-content: center;
        align-items: center;
    }

</style>